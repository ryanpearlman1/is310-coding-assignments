# Command Line Maze
Welcome to the maze! It consists of four paths and a whole bunch of files! Everything is solvable in the command line. In fact, I was able to find the proper location of the file in just one command line of code during testing! 
You are looking for the final page. It will be very obvious when you are fished with the maze.
Start by going to path2, directory 1, and find the secret! (Hint: Files aren't always in plain sight...)





<span style="color:white">Did you highlight the page? Very wise. Your reward? Try path3 out for size.</span>